import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '../../_lib/supabase';
import { theme, getThemeByForce, ForceTheme } from '../theme';

type ThemeContextType = {
    theme: ForceTheme;
    userForce: 'army' | 'navy' | 'airforce' | string;
    isLoading: boolean;
};

const ThemeContext = createContext<ThemeContextType>({
    theme: theme.forces.army,
    userForce: 'army',
    isLoading: true,
});

export const useTheme = () => useContext(ThemeContext);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [currentTheme, setCurrentTheme] = useState<ForceTheme>(theme.forces.army); // Default
    const [userForce, setUserForce] = useState<string>('army');
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        loadUserTheme();
    }, []);

    async function loadUserTheme() {
        try {
            const { data: { user } } = await supabase.auth.getUser();

            if (user) {
                // Fetch user profile to get force
                const { data: profile } = await supabase
                    .from('recrutas')
                    .select('force')
                    .eq('id', user.id)
                    .single();

                if (profile?.force) {
                    setUserForce(profile.force);
                    setCurrentTheme(getThemeByForce(profile.force));
                }
            }
        } catch (error) {
            console.error('Error loading theme:', error);
        } finally {
            setIsLoading(false);
        }
    }

    return (
        <ThemeContext.Provider value={{ theme: currentTheme, userForce, isLoading }}>
            {children}
        </ThemeContext.Provider>
    );
};
