import React from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, Image } from 'react-native';
import { useForceTheme } from '../../src/context/ForceThemeContext';
import { useAuth } from '../../src/context/AuthContext';
import { useMedals, MedalStatus } from '../../src/hooks/useMedals';
import { Header } from '../../src/components/Header';
import { Ionicons } from '@expo/vector-icons';

export default function MedalhasScreen() {
    const { theme } = useForceTheme();
    const { session } = useAuth();
    const { medals, loading } = useMedals(session?.user?.id || '');

    const renderItem = ({ item }: { item: MedalStatus }) => {
        // Visual mappings
        const isGranted = item.status === 'concedida';
        const isEligible = item.status === 'elegível';
        const isBlocked = item.status === 'não elegível' || item.status === 'bloqueada' || (!isGranted && !isEligible);

        return (
            <View style={[
                styles.card,
                {
                    backgroundColor: theme.card,
                    borderColor: isGranted ? theme.primary : isEligible ? 'rgba(255,255,255,0.3)' : 'transparent',
                    borderWidth: isGranted || isEligible ? 1 : 0,
                    opacity: isBlocked ? 0.5 : 1
                }
            ]}>
                <View style={styles.iconContainer}>
                    {isGranted ? (
                        <Ionicons name="ribbon" size={40} color={theme.primary} />
                    ) : isEligible ? (
                        <Ionicons name="ribbon-outline" size={40} color="#FFF" />
                    ) : (
                        <Ionicons name="lock-closed" size={32} color={theme.textSecondary} />
                    )}
                </View>

                <View style={styles.textContainer}>
                    <Text style={[styles.name, { color: theme.textPrimary }]}>{item.nome}</Text>

                    {isGranted && (
                        <Text style={[styles.statusText, { color: theme.primary }]}>CONCEDIDA</Text>
                    )}

                    {isEligible && (
                        <Text style={[styles.statusText, { color: '#FFF' }]}>ELEGÍVEL</Text>
                    )}

                    {/* Critério faltante displayed ONLY if explicitly provided by view */}
                    {item.criterio_faltante && (
                        <Text style={[styles.criteria, { color: theme.textSecondary }]}>
                            Falta: {item.criterio_faltante}
                        </Text>
                    )}
                </View>
            </View>
        );
    };

    if (loading) {
        return (
            <View style={[styles.container, styles.center, { backgroundColor: theme.background }]}>
                <ActivityIndicator size="large" color={theme.primary || '#FFD166'} />
            </View>
        );
    }

    return (
        <View style={[styles.container, { backgroundColor: theme.background }]}>
            <View style={{ paddingHorizontal: 20 }}>
                <Header title="MEDALHAS & CONDECORAÇÕES" />
            </View>

            <FlatList
                data={medals}
                renderItem={renderItem}
                keyExtractor={(item, index) => item.id || `medal-${index}`}
                contentContainerStyle={styles.listContent}
                ListEmptyComponent={
                    <Text style={[styles.emptyText, { color: theme.textSecondary }]}>
                        Nenhuma informação de medalhas disponível.
                    </Text>
                }
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    center: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    listContent: {
        padding: 20,
        gap: 16,
    },
    card: {
        flexDirection: 'row',
        padding: 16,
        borderRadius: 12,
        alignItems: 'center',
        gap: 16,
    },
    iconContainer: {
        width: 60,
        height: 60,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0,0,0,0.2)',
        borderRadius: 30,
    },
    textContainer: {
        flex: 1,
    },
    name: {
        fontSize: 16,
        fontWeight: 'bold',
        marginBottom: 4,
        textTransform: 'uppercase',
    },
    statusText: {
        fontSize: 12,
        fontWeight: 'bold',
        letterSpacing: 1,
    },
    criteria: {
        fontSize: 12,
        marginTop: 4,
        fontStyle: 'italic',
    },
    emptyText: {
        textAlign: 'center',
        marginTop: 40,
        opacity: 0.6,
    }
});
