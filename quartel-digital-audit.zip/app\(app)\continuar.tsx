import React, { useEffect } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { supabase } from '../../src/lib/supabase';
import { useAuth } from '../../src/context/AuthContext';
import { useForceTheme } from '../../src/context/ForceThemeContext';

export default function ContinuarScreen() {
    const router = useRouter();
    const { session } = useAuth();
    const { theme } = useForceTheme();

    useEffect(() => {
        async function navigateToNextLesson() {
            if (!session?.user?.id) return;

            try {
                // 1. Fetch all lessons ordered
                const { data: allLessons, error: lessonsError } = await supabase
                    .from('v_lessons_panel')
                    .select('lesson_id, lesson_order, module')
                    .eq('force', 'marinha') // Hardcoded as per current scope
                    .order('module')
                    .order('lesson_order');

                if (lessonsError) throw lessonsError;

                // 2. Fetch completed lessons
                const { data: completedLessons, error: progressError } = await supabase
                    .from('v_lesson_progress_panel') // Confirmed correct view name from previous steps
                    .select('lesson_id')
                    .eq('user_id', session.user.id);

                if (progressError) throw progressError;

                // 3. Find first uncompleted
                const completedIds = new Set(completedLessons?.map(c => c.lesson_id));
                const nextLesson = allLessons?.find(l => !completedIds.has(l.lesson_id));

                if (nextLesson) {
                    // Navigate to next lesson
                    router.replace({
                        pathname: "/(lessons)/[lessonId]",
                        params: { lessonId: nextLesson.lesson_id }
                    });
                } else if (allLessons && allLessons.length > 0) {
                    // All completed? Go to the last one or stay on panel? 
                    // "Retoma no ponto interrompido" usually implies next to do. 
                    // If all done, maybe the last one is better than nothing, or panel.
                    // Let's go to the last one (review mode)
                    const lastLesson = allLessons[allLessons.length - 1];
                    router.replace({
                        pathname: "/(lessons)/[lessonId]",
                        params: { lessonId: lastLesson.lesson_id }
                    });
                } else {
                    // No lessons found at all
                    router.replace('/');
                }

            } catch (error) {
                console.error("Error finding next lesson:", error);
                router.replace('/'); // Fallback to panel
            }
        }

        navigateToNextLesson();
    }, [session]);

    return (
        <View style={{ flex: 1, backgroundColor: theme.background, justifyContent: 'center', alignItems: 'center' }}>
            <ActivityIndicator size="large" color={theme.primary || '#FFD166'} />
        </View>
    );
}
