import LessonScreen from '../../../src/screens/LessonScreen';

export default LessonScreen;
