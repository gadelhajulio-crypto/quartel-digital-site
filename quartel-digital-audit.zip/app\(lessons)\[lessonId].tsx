import { View, Text, StyleSheet, ScrollView, ActivityIndicator } from 'react-native'
import { useLocalSearchParams, Stack } from 'expo-router'
import { useLessonData } from '../../src/hooks/useLessonData'
import { isLessonBlocked } from '../../src/lib/lessonAccess'
import { VideoCard } from '../../src/components/cards/VideoCard'
import { PdfCard } from '../../src/components/cards/PdfCard'
import { useAuth } from '../../src/context/AuthContext'
import { theme } from '../../src/theme'
import { Header } from '../../src/components/Header'

export default function LessonScreen() {
    const { lessonId } = useLocalSearchParams()
    const { session } = useAuth();
    const userId = session?.user?.id;

    const { data, loading } = useLessonData(String(lessonId), userId)

    if (loading || !data) {
        return (
            <View style={[styles.container, styles.center]}>
                <ActivityIndicator size="large" color={theme.colors.gold || '#FFD166'} />
            </View>
        )
    }

    const blocked = isLessonBlocked(data)

    // Find video media
    const videoMedia = data.lesson_media?.find(m => m.type === 'video');
    const pdfMedia = data.lesson_media?.find(m => m.type === 'pdf');

    return (
        <ScrollView style={styles.container}>
            <Stack.Screen options={{ headerShown: false }} />
            <View style={{ padding: 16 }}>
                <Header title={data.module.toUpperCase()} />

                <Text style={styles.lessonTitle}>{data.title}</Text>

                <VideoCard
                    uri={videoMedia?.url}
                    blocked={blocked}
                />

                <PdfCard uri={pdfMedia?.url} blocked={blocked} />

                {blocked && (
                    <Text style={styles.blockedText}>
                        Conteúdo disponível após progressão no curso.
                    </Text>
                )}
            </View>
        </ScrollView>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
    },
    center: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    lessonTitle: {
        color: theme.colors.textPrimary,
        fontSize: 20,
        fontWeight: 'bold',
        marginBottom: 20,
        marginTop: 10,
    },
    blockedText: {
        color: theme.colors.textSecondary,
        textAlign: 'center',
        marginTop: 20,
    }
});
