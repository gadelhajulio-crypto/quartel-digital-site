export type InstructorProfileId = 'objetivo' | 'estrategico' | 'didatico';

export interface Instructor {
    id: InstructorProfileId;
    name: string;
    description: string;
    image: any; // Using object with uri for remote image
}

export const instructors: Instructor[] = [
    {
        id: 'objetivo',
        name: 'Instrutor Objetivo',
        description:
            'Comunicação direta, clara e sem rodeios. Foco absoluto em regulamentos, disciplina e execução correta das rotinas institucionais.',
        // image: require('../assets/instructor-placeholder.png'), // Fallback requested
        image: { uri: 'https://ui-avatars.com/api/?name=Instrutor+Objetivo&background=1F6FEB&color=fff&size=256' },
    },
    {
        id: 'estrategico',
        name: 'Instrutor Estratégico',
        description:
            'Comunicação analítica e orientada à progressão. Explica o porquê das normas e como cada decisão impacta sua trajetória.',
        image: { uri: 'https://ui-avatars.com/api/?name=Instrutor+Estrategico&background=238636&color=fff&size=256' },
    },
    {
        id: 'didatico',
        name: 'Instrutora Didática',
        description:
            'Comunicação clara, paciente e estruturada. Explica conceitos passo a passo, facilitando o entendimento dos regulamentos.',
        image: { uri: 'https://ui-avatars.com/api/?name=Instrutora+Didatica&background=A371F7&color=fff&size=256' },
    },
];
