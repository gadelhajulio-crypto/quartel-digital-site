import React, { useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useForceTheme } from '../../src/context/ForceThemeContext';
import { Header } from '../../src/components/Header';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as ScreenCapture from 'expo-screen-capture';
import { useFocusEffect } from 'expo-router';

export default function ManualScreen() {
    const { theme } = useForceTheme();

    useFocusEffect(
        React.useCallback(() => {
            const prevent = async () => {
                await ScreenCapture.preventScreenCaptureAsync();
            };
            prevent();

            return () => {
                ScreenCapture.allowScreenCaptureAsync();
            };
        }, [])
    );

    return (
        <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
            <View style={{ paddingHorizontal: 20 }}>
                <Header title="MANUAL & REGRAS" />
            </View>

            <ScrollView
                style={styles.content}
                contentContainerStyle={styles.scrollContent}
            // Security: Prevent selection is tricky in RN Text, usually selectable={false} is default.
            // We ensure no text selection properties are enabled.
            >
                <View style={styles.textBlock}>
                    <Text selectable={false} style={[styles.sectionTitle, { color: theme.primary }]}>
                        1. HIERARQUIA E DISCIPLINA
                    </Text>
                    <Text selectable={false} style={[styles.text, { color: theme.textSecondary }]}>
                        O respeito à hierarquia é o fundamento da disciplina militar. Cada recruta deve conhecer seu lugar na estrutura e respeitar os superiores e pares. A obediência às ordens é absoluta, legal e necessária.
                    </Text>

                    <Text selectable={false} style={[styles.sectionTitle, { color: theme.primary }]}>
                        2. SISTEMA DE XP
                    </Text>
                    <Text selectable={false} style={[styles.text, { color: theme.textSecondary }]}>
                        A Experiência (XP) é concedida com base no mérito individual. Ações como conclusão de módulos, revisões pontuais e acertos em provas geram XP. O XP não expira, mas serve de base para o Ranking mensal.
                    </Text>

                    <Text selectable={false} style={[styles.sectionTitle, { color: theme.primary }]}>
                        3. CONDECORAÇÕES (MEDALHAS)
                    </Text>
                    <Text selectable={false} style={[styles.text, { color: theme.textSecondary }]}>
                        As medalhas são reconhecimentos permanentes por feitos extraordinários.
                        {'\n\n'}
                        - MEDALHA DE HONRA: Concedida por atos de bravura ou desempenho excepcional.
                        {'\n'}
                        - MEDALHA DE DISCIPLINA: Concedida por constância e assiduidade sem falhas durante o período de instrução.
                        {'\n'}
                        - MEDALHA DE TECNOLOGIA: Concedida por domínio técnico superior nas avaliações práticas.
                    </Text>

                    <Text selectable={false} style={[styles.sectionTitle, { color: theme.primary }]}>
                        4. PROMOÇÕES
                    </Text>
                    <Text selectable={false} style={[styles.text, { color: theme.textSecondary }]}>
                        A promoção de patente ocorre mediante cumprimento de requisitos cumulativos: XP total, tempo de serviço e aprovação em exame de qualificação.
                    </Text>

                    <Text selectable={false} style={[styles.sectionTitle, { color: theme.primary }]}>
                        5. CONDUTA NO CHAT
                    </Text>
                    <Text selectable={false} style={[styles.text, { color: theme.textSecondary }]}>
                        O chat com o Instrucional é canal oficial. Linguagem imprópria, desrespeito ou uso indevido resultará em sanções disciplinares e perda de XP.
                    </Text>

                    <Text selectable={false} style={[styles.footer, { color: theme.textSecondary }]}>
                        Regulamento Oficial - Versão 1.0
                        {'\n'}Diretoria de Ensino Quartel Digital
                    </Text>
                </View>
            </ScrollView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    content: {
        flex: 1,
    },
    scrollContent: {
        padding: 20,
        paddingBottom: 40,
    },
    textBlock: {
        gap: 20,
    },
    sectionTitle: {
        fontSize: 16,
        fontWeight: 'bold',
        marginBottom: 8,
        textTransform: 'uppercase',
        letterSpacing: 1,
    },
    text: {
        fontSize: 14,
        lineHeight: 24,
        textAlign: 'justify',
    },
    footer: {
        marginTop: 40,
        textAlign: 'center',
        fontSize: 12,
        opacity: 0.5,
        fontStyle: 'italic',
    }
});
