import React, { useEffect, useState, useMemo } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ActivityIndicator,
    Alert,
    ScrollView,
} from 'react-native';
import { Video, ResizeMode } from 'expo-av';
import * as Linking from 'expo-linking';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useForceTheme } from '../context/ForceThemeContext';
import { Ionicons } from '@expo/vector-icons';
import { fetchLessonById } from '../services/lessons';
import { isLessonBlocked } from '../utils/accessControl';

const BlockedStateView = ({ theme }: { theme: any }) => (
    <View style={[styles.center, { backgroundColor: theme.background }]}>
        <Ionicons name="lock-closed" size={64} color={theme.textSecondary} />
        <Text style={{ color: theme.textPrimary, fontSize: 20, marginTop: 16, fontWeight: 'bold' }}>
            Conteúdo Bloqueado
        </Text>
        <Text style={{ color: theme.textSecondary, marginTop: 8 }}>
            Esta aula é exclusiva para assinantes.
        </Text>
    </View>
);

export default function LessonScreen() {
    const { aulaId } = useLocalSearchParams<any>();

    const router = useRouter();
    const { session } = useAuth();
    const { theme, loading: themeLoading } = useForceTheme();

    // ⭐ THEME LOADING GUARD
    if (themeLoading || !theme) {
        return (
            <View style={{ flex: 1, backgroundColor: '#020B14', justifyContent: 'center', alignItems: 'center' }}>
                <ActivityIndicator size="large" color="#FFD166" />
            </View>
        );
    }

    const userId = session?.user?.id;
    // ⭐ DYNAMIC STYLES with Memo
    const styles = useMemo(() => getStyles(theme), [theme]);

    const [loading, setLoading] = useState(true);
    const [lesson, setLesson] = useState<any>(null);
    const [concluida, setConcluida] = useState(false);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        if (aulaId) {
            loadLessonData();
        }
    }, [aulaId]);

    useEffect(() => {
        if (userId && aulaId) {
            checkConclusao();
        }
    }, [userId, aulaId]);

    const loadLessonData = async () => {
        try {
            const { data, error } = await fetchLessonById(aulaId);
            if (error) {
                console.error("Error fetching lesson:", error);
                Alert.alert("Erro", "Não foi possível carregar a aula.");
                return;
            }
            setLesson(data);
        } catch (err) {
            console.error(err);
        }
    };

    async function checkConclusao() {
        try {
            if (!userId) return;

            const { data } = await supabase
                .from('progresso_aulas')
                .select('id')
                .eq('user_id', userId)
                .eq('aula_id', aulaId)
                .maybeSingle();

            if (data) setConcluida(true);
        } catch (err) {
            console.error('Error checking conclusion:', err);
        } finally {
            setLoading(false); // Only set loading false after checking conclusion (or merge loading states)
            // Ideally we wait for both lesson and conclusion. 
            // But lesson fetch is disjoint from conclusion check.
            // Let's refine loading state.
        }
    }

    // Effect to handle main loading state
    useEffect(() => {
        if (lesson && loading) { // If lesson loaded, we can verify blocking
            // We still wait for conclusion check if needed, but blocking check is prio.
            // If we want to show loading until everything is ready:
            // We can manage a combined loading state.
        }
    }, [lesson]);


    async function concluirAula() {
        if (!userId || !aulaId) return;
        setSaving(true);

        const { error } = await supabase
            .from('progresso_aulas')
            .insert({
                user_id: userId,
                aula_id: aulaId,
            });

        setSaving(false);

        if (error) {
            if (error.code === '23505') {
                console.log('[LESSON] Duplicate completion blocked (23505). Setting state to done.');
                setConcluida(true);
                return;
            }

            Alert.alert(
                'Erro',
                'Não foi possível concluir a aula.'
            );
            return;
        }

        setConcluida(true);

        Alert.alert(
            'Aula concluída',
            'Você ganhou XP por esta aula.',
            [{ text: 'OK', onPress: () => router.back() }]
        );
    }

    if (loading && !lesson) {
        return (
            <View
                style={[
                    styles.center,
                    { backgroundColor: theme.background },
                ]}
            >
                <ActivityIndicator size="large" color={theme.accent} />
            </View>
        );
    }

    // Security Check
    if (lesson && isLessonBlocked(lesson)) {
        return <BlockedStateView theme={theme} />;
    }

    if (!lesson) {
        return (
            <View style={[styles.center, { backgroundColor: theme.background }]}>
                <Text style={{ color: theme.textSecondary }}>Aula não encontrada.</Text>
            </View>
        );
    }

    return (
        <ScrollView
            style={[
                styles.container,
                { backgroundColor: theme.background },
            ]}
        >
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
                <TouchableOpacity onPress={() => router.back()} style={{ marginRight: 10 }}>
                    <Ionicons name="arrow-back" size={24} color={theme.textPrimary} />
                </TouchableOpacity>
                <Text
                    style={[
                        styles.title,
                        { color: theme.textPrimary, flex: 1 },
                    ]}
                >
                    {lesson.title}
                </Text>
            </View>

            {/* 🎥 VÍDEO */}
            {lesson.video_url ? (
                <Video
                    source={{ uri: lesson.video_url }}
                    useNativeControls
                    resizeMode={ResizeMode.CONTAIN}
                    style={styles.video}
                />
            ) : (
                <View style={[styles.video, { backgroundColor: '#000', justifyContent: 'center', alignItems: 'center' }]}>
                    <Text style={{ color: '#fff' }}>Vídeo indisponível</Text>
                </View>
            )}

            {/* 📄 PDF */}
            {lesson.pdf_url && (
                <TouchableOpacity
                    style={[
                        styles.pdfButton,
                        { borderColor: theme.accent },
                    ]}
                    onPress={() => Linking.openURL(lesson.pdf_url)}
                >
                    <Ionicons
                        name="document-text-outline"
                        size={20}
                        color={theme.accent}
                    />
                    <Text
                        style={[
                            styles.pdfText,
                            { color: theme.accent },
                        ]}
                    >
                        Abrir material em PDF
                    </Text>
                </TouchableOpacity>
            )}

            {/* ✅ CONCLUIR */}
            <TouchableOpacity
                disabled={concluida || saving}
                onPress={concluirAula}
                style={[
                    styles.concluirButton,
                    {
                        backgroundColor: concluida
                            ? theme.card
                            : theme.accent,
                    },
                ]}
            >
                <Ionicons
                    name={concluida ? 'checkmark-circle' : 'checkmark'}
                    size={20}
                    color={concluida ? theme.textSecondary : theme.background}
                />
                <Text
                    style={[
                        styles.concluirText,
                        {
                            color: concluida
                                ? theme.textSecondary
                                : theme.background,
                        },
                    ]}
                >
                    {concluida ? 'Aula concluída' : 'Marcar como concluída'}
                </Text>
            </TouchableOpacity>
        </ScrollView>
    );
}

const getStyles = (theme: any) => StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
    },
    center: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    title: {
        fontSize: 20,
        fontWeight: '600',
    },
    video: {
        width: '100%',
        height: 220,
        borderRadius: 12,
        marginBottom: 16,
    },
    pdfButton: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        padding: 14,
        borderWidth: 1,
        borderRadius: 10,
        marginBottom: 24,
    },
    pdfText: {
        fontSize: 14,
        fontWeight: '500',
    },
    concluirButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        padding: 16,
        borderRadius: 12,
    },
    concluirText: {
        fontSize: 16,
        fontWeight: '600',
    },
});
