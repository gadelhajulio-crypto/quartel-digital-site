import React, { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, Alert } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { supabase } from '../../../../../src/lib/supabase';
import { useAuth } from '../../../../../src/context/AuthContext';
import LessonScreen from '../../../../../src/screens/LessonScreen';
import { canAccessModule } from '../../../../../src/utils/accessControl';
import { completeLesson } from '../../../../../src/services/progressService';
import { theme } from '../../../../../src/theme';

type LessonData = {
    id: string;
    titulo: string;
    descricao: string;
    video_url: string;
    pdf_url?: string;
    modulo_id: string;
};

type ModuloInfo = {
    id: string;
    is_degustacao: boolean;
};

export default function LessonRoute() {
    const { id, aulaId } = useLocalSearchParams(); // id = module_id, aulaId = lesson_id
    const { session, profile } = useAuth();
    const router = useRouter();

    const [lesson, setLesson] = useState<LessonData | null>(null);
    const [loading, setLoading] = useState(true);
    const [denied, setDenied] = useState(false);

    useEffect(() => {
        if (!session || !profile || !id || !aulaId) return;

        loadContent();
    }, [session, profile, id, aulaId]);

    const loadContent = async () => {
        try {
            setLoading(true);

            // 1. Verify Module Access First (Security First)
            const { data: moduleData, error: moduleError } = await supabase
                .from('modulos')
                .select('id, is_degustacao')
                .eq('id', id)
                .single();

            if (moduleError || !moduleData) {
                throw new Error("Module not found");
            }

            // 🛑 STOP if access denied
            if (!canAccessModule(profile!, moduleData)) {
                setDenied(true);
                return;
            }

            // 2. Fetch Lesson Data
            const { data: lessonData, error: lessonError } = await supabase
                .from('aulas') // Assuming table 'aulas'
                .select('id, titulo, descricao, video_url, pdf_url, modulo_id')
                .eq('id', aulaId)
                .single();

            if (lessonError) throw lessonError;

            setLesson(lessonData);

        } catch (err) {
            console.error('Error loading lesson:', err);
            Alert.alert('Erro', 'Falha ao carregar conteúdo da aula.');
            router.back();
        } finally {
            setLoading(false);
        }
    };

    const handleLessonComplete = async () => {
        if (session?.user?.id && aulaId) {
            await completeLesson(aulaId as string, session.user.id);
            // Optional: Toast or feedback?
        }
    };

    if (loading) {
        return (
            <View style={{ flex: 1, backgroundColor: theme.colors.background, justifyContent: 'center', alignItems: 'center' }}>
                <ActivityIndicator color={theme.colors.gold} size="large" />
            </View>
        );
    }

    if (denied) {
        // Redirect or show Access Denied
        // Better UX: Show "Restricted" screen or pop back immediately
        return (
            <View style={{ flex: 1, backgroundColor: theme.colors.background, justifyContent: 'center', alignItems: 'center', padding: 20 }}>
                <Text style={{ color: theme.colors.gold, fontSize: 18, fontWeight: 'bold', marginBottom: 10 }}>ACESSO RESTRITO</Text>
                <Text style={{ color: theme.colors.textSecondary, marginBottom: 20 }}>Você não tem permissão para visualizar esta aula no momento.</Text>
                <Text style={{ color: theme.colors.gold }} onPress={() => router.back()}>VOLTAR</Text>
            </View>
        );
    }

    return (
        <LessonScreen
            licao={lesson!}
            onComplete={handleLessonComplete}
        />
    );
}
