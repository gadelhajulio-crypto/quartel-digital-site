import React from 'react';
import { View, Text, StyleSheet } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { VideoPlayer } from "../../src/components/VideoPlayer";
import { aulas } from "../../src/data/aulas";
import { theme } from "../../src/theme";
import { Header } from "../../src/components/Header";

export default function AulaPlayer() {
    const { id } = useLocalSearchParams();
    const aula = aulas.find(a => a.id === id);

    if (!aula) return <View style={styles.container}><Text style={{ color: 'white' }}>Aula não encontrada</Text></View>;

    return (
        <View style={styles.container}>
            <VideoPlayer uri={aula.video} />
            <View style={{ padding: 16 }}>
                <Header title={aula.title} />
                <Text style={styles.desc}>{aula.description}</Text>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: theme.colors.background,
        flex: 1,
    },
    title: {
        color: theme.colors.textPrimary,
        fontSize: 18,
        fontWeight: "700",
        margin: 16,
    },
    desc: {
        color: theme.colors.textSecondary,
        fontSize: 14,
        lineHeight: 20,
    },
});
