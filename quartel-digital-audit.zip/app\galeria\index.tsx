import {
  View,
  Text,
  FlatList,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
} from "react-native";
import { useEffect, useState } from "react";
import { useRouter } from "expo-router";
import { fetchGaleria } from "../../src/services/galeria";
import { colors } from "../../src/theme"; // ✅ IMPORTA O TEMA

export default function GaleriaScreen() {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    fetchGaleria()
      .then(setData)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={colors.gold} />
      </View>
    );
  }

  if (!data.length) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.emptyText}>Nenhum recruta padrão registrado.</Text>
      </View>
    );
  }

  const destaque = data[0];
  const historico = data.slice(1);

  return (
    <FlatList
      style={styles.container}
      ListHeaderComponent={
        <View style={styles.header}>
          <Text style={styles.title}>
            🎖 Recruta Padrão do Mês
          </Text>

          <TouchableOpacity
            onPress={() => router.push(`/galeria/${destaque.id}`)}
            style={styles.destaqueCard}
          >
            <Image
              source={
                destaque.foto_url
                  ? { uri: destaque.foto_url }
                  : { uri: "https://ui-avatars.com/api/?name=Recruta&background=0A2540&color=fff" }
              }
              style={styles.destaqueImage}
            />

            <Text style={styles.destaqueLabel}>
              Destaque do mês
            </Text>
          </TouchableOpacity>

          <Text style={styles.sectionTitle}>
            Histórico
          </Text>
        </View>
      }
      data={historico}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <TouchableOpacity
          onPress={() => router.push(`/galeria/${item.id}`)}
          style={styles.historicoItem}
        >
          <Image
            source={
              item.foto_url
                ? { uri: item.foto_url }
                : { uri: "https://ui-avatars.com/api/?name=Recruta&background=0A2540&color=fff" }
            }
            style={styles.historicoImage}
          />

          <View>
            <Text style={styles.historicoTitle}>Recruta Padrão</Text>
            <Text style={styles.historicoDate}>
              {new Date(item.created_at).toLocaleDateString('pt-BR')}
            </Text>
          </View>
        </TouchableOpacity>
      )}
    />
  );
}

// ✅ STYLES COM TEMA
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  centerContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: colors.background,
  },
  emptyText: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  header: {
    padding: 16,
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    color: colors.textPrimary,
    marginBottom: 12,
  },
  destaqueCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    alignItems: "center",
    elevation: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
  },
  destaqueImage: {
    width: 140,
    height: 140,
    borderRadius: 70,
    marginBottom: 12,
    backgroundColor: colors.border,
  },
  destaqueLabel: {
    color: colors.gold,
    fontSize: 16,
    fontWeight: "600",
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: colors.textPrimary,
    marginVertical: 16,
  },
  historicoItem: {
    flexDirection: "row",
    padding: 16,
    alignItems: "center",
    borderBottomWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.background,
  },
  historicoImage: {
    width: 48,
    height: 48,
    borderRadius: 24,
    marginRight: 12,
    backgroundColor: colors.border,
  },
  historicoTitle: {
    fontWeight: "bold",
    color: colors.textPrimary,
    fontSize: 14,
  },
  historicoDate: {
    color: colors.textSecondary,
    fontSize: 12,
    marginTop: 2,
  },
});