import React from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { theme } from '../../../src/theme';
import { SinoDeBordo } from '../../../src/components/SinoDeBordo';

export default function SinoScreen() {
    return (
        <View style={styles.container}>
            <ScrollView contentContainerStyle={styles.content}>
                <SinoDeBordo />
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
    },
    content: {
        padding: theme.spacing.m,
    },
});
