import React, { useEffect } from 'react';
import { Tabs, useRouter, usePathname } from 'expo-router';
import { ThemeProvider, useTheme } from '../../src/context/ThemeContext';
import { View, ActivityIndicator, Platform } from 'react-native';
import BottomBar from '../../src/components/navigation/BottomBar';
import { useAuth } from '../../src/context/AuthContext';

function ProtectedLayoutContent() {
  const { theme, isLoading } = useTheme();
  const { profile, loading: authLoading } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  // 🔒 REDIRECT LOGIC: Force Instructor Selection
  useEffect(() => {
    if (authLoading || isLoading || !profile) return;

    const isSelecting = pathname.includes('/instructor-select'); // Check new path

    // If user has no instructor selected and is NOT on selection screen, redirect
    if (!profile.instructor_profile_id && !isSelecting) {
      console.log('[LAYOUT] Missing instructor. Redirecting to selection.');
      router.replace('/(onboarding)/instructor-select');
    }
  }, [profile, authLoading, isLoading, pathname]);

  if (isLoading || authLoading) {
    return (
      <View style={{ flex: 1, backgroundColor: '#000', justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#FFD700" />
      </View>
    );
  }

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
      }}
      tabBar={(props) => <BottomBar />}
    >
      <Tabs.Screen name="index" />
      <Tabs.Screen name="instrutor/index" />

      {/* New Route: Continuar */}
      <Tabs.Screen name="continuar" />

      {/* Removed: perfil/index */}

      {/* Hidden Routes */}
      <Tabs.Screen name="instrutor/selecionar" options={{ href: null, tabBarStyle: { display: 'none' } }} />
      <Tabs.Screen name="ranking" options={{ href: null }} />
      <Tabs.Screen name="perfil/index" options={{ href: null, tabBarStyle: { display: 'none' } }} />
      {/* Keeping legacy perfil/index hidden/disabled just in case file exists to avoid router error, or I can delete it from tabs if file deleted. 
          The user said REMOVE from footer. I'll hide it here or ideally remove the file reference if I'm sure.
          Since I haven't deleted the file `app/(app)/perfil/index.tsx`, I should keep it hidden or let it be reachable only via direct link if needed (but user said only via header). 
          Wait, user said "Perfil acessível somente pelo ícone no topo". So the route MUST exist, just not in footer.
          So Tabs.Screen name="perfil/index" options={{ href: null }} is CORRECT.
      */}

      <Tabs.Screen name="aulas" options={{ href: null }} />
      <Tabs.Screen name="chat" options={{ href: null }} />
    </Tabs>
  );
}

export default function ProtectedLayout() {
  return (
    <ThemeProvider>
      <ProtectedLayoutContent />
    </ThemeProvider>
  );
}
