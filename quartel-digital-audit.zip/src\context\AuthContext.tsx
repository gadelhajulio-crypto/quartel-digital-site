import React, { createContext, useContext, useEffect, useState } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

// 🔐 TIPOS
interface AuthContextType {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  refetchProfile: () => Promise<void>;
}

export type Profile = {
  id: string;
  nome: string;
  patente: string;
  forca: 'marinha' | 'exercito' | 'aeronautica';
  nivel_atual: number;
  xp: number;
  avatar_url?: string;
  instructor_profile_id?: 'objetivo' | 'estrategico' | 'didatico' | null;
  tipo_acesso: 'degustacao' | 'completo';
  ativo: boolean;
};

// 🏗️ CRIAÇÃO DO CONTEXTO
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// 🎯 PROVIDER
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  // 🔄 CARREGAR PERFIL (Centralizado)
  const loadProfile = React.useCallback(async (userId: string) => {
    try {
      console.log('[AUTH] Loading profile for:', userId);
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) {
        console.error('[AUTH] Error loading profile:', error);
        // Fallback default profile if missing
        setProfile({
          id: userId,
          nome: 'Recruta',
          patente: 'Recruta Zero',
          forca: 'marinha',
          nivel_atual: 1,
          xp: 0
        } as Profile);
      } else {
        setProfile(data);
        console.log('[AUTH] Profile loaded:', data.nome);
      }
    } catch (e) {
      console.error('[AUTH] Exception loading profile:', e);
    }
  }, []);

  // 🔄 INICIALIZAÇÃO: Verifica se já tem sessão ativa
  useEffect(() => {
    console.log('[AUTH CONTEXT] 🚀 Inicializando...');

    // Função para obter sessão inicial
    const initializeAuth = async () => {
      try {
        const { data: { session: currentSession }, error } = await supabase.auth.getSession();

        if (error) {
          console.error('[AUTH CONTEXT] ❌ Erro ao obter sessão:', error);
        }

        if (currentSession) {
          console.log('[AUTH CONTEXT] ✅ Sessão existente encontrada:', {
            userId: currentSession.user.id,
            email: currentSession.user.email
          });
          setSession(currentSession);
          setUser(currentSession.user);
          await loadProfile(currentSession.user.id);
        } else {
          console.log('[AUTH CONTEXT] ℹ️ Nenhuma sessão ativa');
          setSession(null);
          setUser(null);
          setProfile(null);
        }
      } catch (error) {
        console.error('[AUTH CONTEXT] ❌ Erro na inicialização:', error);
      } finally {
        setLoading(false);
        console.log('[AUTH CONTEXT] ✓ Inicialização completa');
      }
    };

    initializeAuth();
  }, [loadProfile]);

  // 🔔 LISTENER: Detecta mudanças de autenticação (login, logout, token refresh)
  useEffect(() => {
    console.log('[AUTH CONTEXT] 🔔 Configurando listener de auth...');

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, currentSession) => {
        console.log('[AUTH CONTEXT] 🔔 Evento de auth:', event, {
          hasSession: !!currentSession,
          userId: currentSession?.user?.id
        });

        // ⭐ ATUALIZA O ESTADO BASEADO NO EVENTO
        switch (event) {
          case 'SIGNED_IN':
            console.log('[AUTH CONTEXT] ✅ SIGNED_IN detectado');
            setSession(currentSession);
            setUser(currentSession?.user ?? null);
            if (currentSession?.user) {
              await loadProfile(currentSession.user.id);
            }
            setLoading(false); // Only stop loading after profile attempt
            break;

          case 'SIGNED_OUT':
            console.log('[AUTH CONTEXT] 🚪 SIGNED_OUT detectado');
            setSession(null);
            setUser(null);
            setProfile(null);
            setLoading(false);
            break;

          case 'TOKEN_REFRESHED':
            console.log('[AUTH CONTEXT] 🔄 TOKEN_REFRESHED detectado');
            setSession(currentSession);
            setUser(currentSession?.user ?? null);
            // Optional: Reload profile on refresh? Usually not needed unless claims changed.
            break;

          case 'USER_UPDATED':
            console.log('[AUTH CONTEXT] 👤 USER_UPDATED detectado');
            setSession(currentSession);
            setUser(currentSession?.user ?? null);
            if (currentSession?.user) {
              await loadProfile(currentSession.user.id);
            }
            break;

          default:
            console.log('[AUTH CONTEXT] ℹ️ Outro evento:', event);
            setSession(currentSession);
            setUser(currentSession?.user ?? null);
            setLoading(false);
        }

        // Log do estado após atualização
        console.log('[AUTH CONTEXT] 📊 Estado atualizado:', {
          hasSession: !!currentSession,
          loading: false
        });
      }
    );

    // Cleanup: Remove listener quando componente desmontar
    return () => {
      console.log('[AUTH CONTEXT] 🧹 Removendo listener de auth');
      subscription.unsubscribe();
    };
  }, [loadProfile]);

  // 🔑 FUNÇÃO DE LOGIN
  const signIn = async (email: string, password: string) => {
    console.log('[AUTH CONTEXT] 🔑 Executando signIn...');
    setLoading(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      console.log('[AUTH CONTEXT] ✅ Login bem-sucedido via signIn()');

      // ⭐ NÃO precisa atualizar state aqui
      // O onAuthStateChange vai detectar e atualizar automaticamente

    } catch (error: any) {
      console.error('[AUTH CONTEXT] ❌ Erro no login:', error.message);
      setLoading(false);
      throw error;
    }
  };

  // 🚪 FUNÇÃO DE LOGOUT
  const signOut = async () => {
    console.log('[AUTH CONTEXT] 🚪 Executando signOut...');

    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;

      console.log('[AUTH CONTEXT] ✅ Logout bem-sucedido');

      // ⭐ NÃO precisa atualizar state aqui
      // O onAuthStateChange vai detectar e atualizar automaticamente

    } catch (error: any) {
      console.error('[AUTH CONTEXT] ❌ Erro no logout:', error.message);
      throw error;
    }
  };

  // 📊 LOG DO ESTADO ATUAL (para debug)
  useEffect(() => {
    console.log('[AUTH CONTEXT] 📊 Estado:', {
      hasSession: !!session,
      loading,
      userId: user?.id
    });
  }, [session, loading, user]);

  // 🎯 PROVIDER VALUE
  const value: AuthContextType = {
    session,
    user,
    profile, // Exposed
    refetchProfile: () => user ? loadProfile(user.id) : Promise.resolve(), // Exposed for manual updates
    loading,
    signIn,
    signOut,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// 🪝 HOOK PERSONALIZADO
export function useAuth() {
  const context = useContext(AuthContext);

  if (context === undefined) {
    throw new Error('useAuth deve ser usado dentro de um AuthProvider');
  }

  return context;
}