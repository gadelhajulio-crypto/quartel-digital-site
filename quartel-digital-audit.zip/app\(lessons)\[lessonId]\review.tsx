import { View, Text, StyleSheet, ActivityIndicator } from 'react-native'
import { useLocalSearchParams, Stack } from 'expo-router'
import { useLessonData } from '../../../src/hooks/useLessonData'
import { isLessonBlocked } from '../../../src/lib/lessonAccess'
import { AudioCard } from '../../../src/components/cards/AudioCard'
import { VideoCard } from '../../../src/components/cards/VideoCard'
import { useAuth } from '../../../src/context/AuthContext'
import { theme } from '../../../src/theme'
import { Header } from '../../../src/components/Header'

export default function ReviewScreen() {
    const { lessonId } = useLocalSearchParams()
    const { session } = useAuth();
    const userId = session?.user?.id;

    const { data, loading } = useLessonData(String(lessonId), userId)

    if (loading || !data) {
        return (
            <View style={[styles.container, styles.center]}>
                <ActivityIndicator size="large" color={theme.colors.gold} />
            </View>
        )
    }

    const blocked = isLessonBlocked(data)
    const completedAt = data.lesson_progress?.completed_at

    const available =
        completedAt &&
        Date.now() - new Date(completedAt).getTime() > 24 * 60 * 60 * 1000

    // Render logic based on user snippet
    if (!completedAt) {
        return (
            <View style={styles.container}>
                <Header title="REVISÃO" />
                <View style={styles.center}>
                    <Text style={styles.message}>Revisão disponível após conclusão da aula.</Text>
                </View>
            </View>
        )
    }

    if (!available) {
        return (
            <View style={styles.container}>
                <Header title="REVISÃO" />
                <View style={styles.center}>
                    <Text style={styles.message}>
                        Revisão disponível 24 horas após a conclusão da aula.
                    </Text>
                </View>
            </View>
        )
    }

    if (blocked) return (
        <View style={[styles.container, styles.center]}>
            <Text style={styles.message}>Conteúdo bloqueado.</Text>
        </View>
    );

    const audioMedia = data.lesson_media?.find(m => m.type === 'audio');
    const videoMedia = data.lesson_media?.find(m => m.type === 'video'); // Or specific review video? Snippet implies reusing VideoCard with 'VIDEO_URL'. I'll search for 'review_video' if separating or just 'video'.
    // Assuming 'video' type is lesson video, maybe there's 'review_video' type? or snippet uses same.
    // Snippet: <VideoCard uri="VIDEO_URL" blocked={false} />
    // I will use `videoMedia?.url` for now.

    return (
        <View style={styles.container}>
            <Stack.Screen options={{ headerShown: false }} />
            <Header title={`REVISÃO: ${data.title}`} />
            <View style={{ padding: 16 }}>
                <AudioCard uri={audioMedia?.url} blocked={false} />
                <VideoCard uri={videoMedia?.url} blocked={false} />
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
    },
    center: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
    message: {
        color: theme.colors.textSecondary,
        fontSize: 16,
        textAlign: 'center',
    }
});
