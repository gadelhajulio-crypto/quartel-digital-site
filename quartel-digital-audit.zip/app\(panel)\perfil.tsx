import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity, Modal, ActivityIndicator } from 'react-native';
import { useAuth } from '../../src/context/AuthContext';
import { useForceTheme } from '../../src/context/ForceThemeContext';
import { useMedals, MedalStatus } from '../../src/hooks/useMedals'; // Reusing hook from Phase A
import { INSTRUCTOR_AVATARS } from '../../src/constants/instructorAvatars';
import { Header } from '../../src/components/Header';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

// Helper for F2: Formal Progress Text
// Since we cannot calculate, we must rely on what we have.
// Ideally this comes from a hook or constant.
// For now, I'll use a placeholder logic based on XP if valid, or generic text.
// "Faltam X XP" implies I know the target.
// I'll define simple static targets for display purposes if not in DB, 
// OR simpler: just show "XP Total: X" if I can't determine missing.
// However, the requirement is strict: "Texto institucional: 'Faltam X XP...'"
// I will define a static map for ranks to calculate visual text ONLY, not business logic.
// This is strictly for display (UX).
const RANK_THRESHOLDS = [
    { rank: 'Recruta Zero', start: 0, next: 1000 },
    { rank: 'Soldado', start: 1000, next: 2500 },
    { rank: 'Cabo', start: 2500, next: 5000 },
    { rank: 'Sargento', start: 5000, next: 10000 },
    // Add more if known, else fallback
];

export default function ProfileScreen() {
    const { profile } = useAuth();
    const { theme } = useForceTheme();
    const router = useRouter();
    const { medals, loading: medalsLoading } = useMedals(profile?.id || '');
    const [selectedMedal, setSelectedMedal] = useState<MedalStatus | null>(null);

    // F1: IDENTIFICAÇÃO INSTITUCIONAL
    const name = profile?.nome || 'Recruta';
    const force = profile?.forca?.toUpperCase() || 'FORÇA DESCONHECIDA';
    const rank = profile?.patente || 'N/A';

    // F2: PROGRESSO FORMAL
    // Assumption: profile.xp is total.
    const currentXP = profile?.xp || 0;
    const currentRankObj = RANK_THRESHOLDS.find(r => r.rank === rank) || RANK_THRESHOLDS[0];
    const nextXP = currentRankObj.next;
    const missingXP = nextXP - currentXP;

    const progressText = nextXP > currentXP
        ? `Faltam ${missingXP} XP para a próxima promoção`
        : "Grau máximo atingido no nível atual";

    // F5: INSTRUTOR
    const instructorId = profile?.instructor_profile_id || 'objetivo';
    const instructorAvatar = INSTRUCTOR_AVATARS[instructorId];

    if (!profile) {
        return (
            <View style={[styles.center, { backgroundColor: theme.background }]}>
                <ActivityIndicator color={theme.primary} />
            </View>
        );
    }

    return (
        <ScrollView style={[styles.container, { backgroundColor: theme.background }]}>
            <Header title="PERFIL DO RECRUTA" />

            <View style={styles.content}>

                {/* F1: IDENTIFICAÇÃO INSTITUCIONAL */}
                <View style={[styles.card, { backgroundColor: theme.card, borderColor: theme.primary, borderWidth: 1 }]}>
                    <View style={styles.headerRow}>
                        <View style={styles.avatarPlaceholder}>
                            <Ionicons name="person" size={30} color={theme.primary} />
                        </View>
                        <View>
                            <Text style={[styles.name, { color: theme.textPrimary }]}>{name}</Text>
                            <Text style={[styles.force, { color: theme.textSecondary }]}>{force}</Text>
                        </View>
                    </View>
                    <View style={styles.divider} />
                    <Text style={[styles.rankLabel, { color: theme.textSecondary }]}>PATENTE ATUAL</Text>
                    <Text style={[styles.rankValue, { color: theme.primary }]}>{rank}</Text>
                </View>

                {/* F2: PROGRESSO FORMAL */}
                <View style={[styles.card, { backgroundColor: theme.card }]}>
                    <Text style={[styles.sectionTitle, { color: theme.textSecondary }]}>REGISTRO DE EXPERIÊNCIA</Text>
                    <View style={styles.xpRow}>
                        <Text style={[styles.xpValue, { color: theme.textPrimary }]}>{currentXP} XP</Text>
                        <Text style={[styles.xpLabel, { color: theme.textSecondary }]}>TOTAL ACUMULADO</Text>
                    </View>
                    <Text style={[styles.progressNote, { color: theme.textSecondary }]}>
                        {progressText}
                    </Text>
                </View>

                {/* F3: CONDECORAÇÕES */}
                <View style={[styles.card, { backgroundColor: theme.card }]}>
                    <Text style={[styles.sectionTitle, { color: theme.textSecondary }]}>CONDECORAÇÕES</Text>
                    {medalsLoading ? (
                        <ActivityIndicator color={theme.primary} />
                    ) : (
                        <View style={styles.medalsGrid}>
                            {medals.length > 0 ? medals.map((medal, idx) => {
                                const isGranted = medal.status === 'concedida';
                                const isEligible = medal.status === 'elegível';
                                const isBlocked = !isGranted && !isEligible;

                                return (
                                    <TouchableOpacity
                                        key={idx}
                                        style={[
                                            styles.medalItem,
                                            {
                                                opacity: isBlocked ? 0.3 : 1,
                                                borderColor: isGranted ? theme.primary : 'transparent',
                                                borderWidth: isGranted ? 1 : 0
                                            }
                                        ]}
                                        onPress={() => setSelectedMedal(medal)}
                                    >
                                        <Ionicons
                                            name={isGranted ? "ribbon" : isEligible ? "ribbon-outline" : "lock-closed"}
                                            size={32}
                                            color={isGranted ? theme.primary : theme.textSecondary}
                                        />
                                    </TouchableOpacity>
                                );
                            }) : (
                                <Text style={{ color: theme.textSecondary, fontSize: 12 }}>Nenhuma condecoração listada.</Text>
                            )}
                        </View>
                    )}
                </View>

                {/* F4: ATALHO HISTÓRICO */}
                <TouchableOpacity
                    style={[styles.actionButton, { borderColor: theme.primary }]}
                    onPress={() => router.push('/(panel)/historico')}
                >
                    <Text style={[styles.actionText, { color: theme.primary }]}>VER HISTÓRICO COMPLETO</Text>
                    <Ionicons name="time-outline" size={20} color={theme.primary} />
                </TouchableOpacity>

                {/* F5: INSTRUTOR DISCRETO */}
                <View style={[styles.instructorRow, { backgroundColor: 'rgba(0,0,0,0.2)' }]}>
                    <Image source={instructorAvatar} style={styles.instructorAvatar} />
                    <View>
                        <Text style={[styles.instructorLabel, { color: theme.textSecondary }]}>INSTRUTOR DESIGNADO</Text>
                        <Text style={[styles.instructorName, { color: theme.textPrimary }]}>
                            {instructorId.charAt(0).toUpperCase() + instructorId.slice(1)}
                        </Text>
                    </View>
                </View>

            </View>

            {/* MODAL F3 */}
            <Modal
                visible={!!selectedMedal}
                transparent
                animationType="fade"
                onRequestClose={() => setSelectedMedal(null)}
            >
                <View style={styles.modalOverlay}>
                    <View style={[styles.modalContent, { backgroundColor: theme.card }]}>
                        {selectedMedal && (
                            <>
                                <Ionicons
                                    name={selectedMedal.status === 'concedida' ? "ribbon" : "lock-closed"}
                                    size={48}
                                    color={selectedMedal.status === 'concedida' ? theme.primary : theme.textSecondary}
                                    style={{ marginBottom: 16 }}
                                />
                                <Text style={[styles.modalTitle, { color: theme.textPrimary }]}>{selectedMedal.nome}</Text>
                                <View style={[
                                    styles.statusBadge,
                                    { backgroundColor: selectedMedal.status === 'concedida' ? theme.primary : '#333' }
                                ]}>
                                    <Text style={styles.statusText}>{selectedMedal.status.toUpperCase()}</Text>
                                </View>

                                {selectedMedal.criterio_faltante && (
                                    <Text style={[styles.modalCriteria, { color: theme.textSecondary }]}>
                                        Requisito pendente: {selectedMedal.criterio_faltante}
                                    </Text>
                                )}

                                <TouchableOpacity
                                    style={[styles.closeButton, { borderColor: theme.textSecondary }]}
                                    onPress={() => setSelectedMedal(null)}
                                >
                                    <Text style={{ color: theme.textSecondary }}>FECHAR</Text>
                                </TouchableOpacity>
                            </>
                        )}
                    </View>
                </View>
            </Modal>

        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    center: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    content: {
        padding: 20,
        gap: 20,
    },
    card: {
        padding: 20,
        borderRadius: 12,
        backgroundColor: '#1E1E1E',
    },
    headerRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 16,
    },
    avatarPlaceholder: {
        width: 50,
        height: 50,
        borderRadius: 25,
        backgroundColor: 'rgba(255,255,255,0.1)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    name: {
        fontSize: 18,
        fontWeight: 'bold',
        textTransform: 'uppercase',
    },
    force: {
        fontSize: 12,
        letterSpacing: 1,
        marginTop: 4,
    },
    divider: {
        height: 1,
        backgroundColor: 'rgba(255,255,255,0.1)',
        marginVertical: 16,
    },
    rankLabel: {
        fontSize: 10,
        fontWeight: 'bold',
        marginBottom: 4,
    },
    rankValue: {
        fontSize: 16,
        fontWeight: 'bold',
        textTransform: 'uppercase',
    },
    sectionTitle: {
        fontSize: 12,
        fontWeight: 'bold',
        marginBottom: 16,
        letterSpacing: 1,
        opacity: 0.7,
    },
    xpRow: {
        flexDirection: 'row',
        alignItems: 'baseline',
        gap: 8,
        marginBottom: 8,
    },
    xpValue: {
        fontSize: 32,
        fontWeight: 'bold',
    },
    xpLabel: {
        fontSize: 10,
        fontWeight: 'bold',
    },
    progressNote: {
        fontSize: 12,
        fontStyle: 'italic',
    },
    medalsGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: 12,
    },
    medalItem: {
        width: 60,
        height: 60,
        borderRadius: 30,
        backgroundColor: 'rgba(0,0,0,0.2)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    actionButton: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 16,
        borderRadius: 12,
        borderWidth: 1,
        gap: 10,
    },
    actionText: {
        fontWeight: 'bold',
        fontSize: 14,
    },
    instructorRow: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 16,
        borderRadius: 12,
        gap: 16,
    },
    instructorAvatar: {
        width: 40,
        height: 40,
        borderRadius: 20,
    },
    instructorLabel: {
        fontSize: 10,
        fontWeight: 'bold',
        marginBottom: 2,
    },
    instructorName: {
        fontSize: 14,
        fontWeight: 'bold',
    },
    modalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0,0,0,0.8)',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
    modalContent: {
        width: '100%',
        maxWidth: 300,
        padding: 24,
        borderRadius: 16,
        alignItems: 'center',
    },
    modalTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 12,
        textAlign: 'center',
        textTransform: 'uppercase',
    },
    statusBadge: {
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 4,
        marginBottom: 16,
    },
    statusText: {
        color: '#FFF',
        fontSize: 12,
        fontWeight: 'bold',
    },
    modalCriteria: {
        textAlign: 'center',
        marginBottom: 24,
        lineHeight: 20,
    },
    closeButton: {
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderWidth: 1,
        borderRadius: 8,
    }
});
