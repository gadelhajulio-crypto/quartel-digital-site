import React from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { useRecruitPanel } from '../../src/hooks/useRecruitPanel';
import { useAuth } from '../../src/context/AuthContext';
import { useForceTheme } from '../../src/context/ForceThemeContext';
import { Header } from '../../src/components/Header';
import { Ionicons } from '@expo/vector-icons';

export default function PanelScreen() {
    const router = useRouter();
    const { session } = useAuth();
    const { theme } = useForceTheme();

    const userId = session?.user?.id;
    const userForce = 'marinha'; // Hardcoded for now

    const { xp, ranking, completed, isChampion, pendingReviews, loading } = useRecruitPanel(userId!, userForce);

    if (loading) {
        return (
            <View style={[styles.center, { backgroundColor: theme.background }]}>
                <ActivityIndicator size="large" color={theme.primary || '#FFD166'} />
            </View>
        );
    }

    return (
        <ScrollView style={[styles.container, { backgroundColor: theme.background }]}>
            <Header
                title="PAINEL DO RECRUTA"
                rightAction={
                    <TouchableOpacity onPress={() => router.push('/perfil')}>
                        <Ionicons name="person-circle-outline" size={32} color={theme.primary} />
                    </TouchableOpacity>
                }
            />

            <View style={styles.content}>
                {/* 1. CARD REVISÕES (Always visible) */}
                <TouchableOpacity
                    style={[styles.card, { borderLeftColor: theme.primary, borderLeftWidth: 4 }]}
                    onPress={() => router.replace('/continuar')} // Using 'continuar' as the action flow
                >
                    <View style={styles.cardRow}>
                        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                            <Ionicons name="refresh-circle" size={32} color={theme.primary} />
                            <View>
                                <Text style={[styles.cardTitle, { color: theme.textSecondary }]}>REVISÕES</Text>
                                <Text style={[styles.cardSubtitle, { color: theme.textSecondary }]}>
                                    {pendingReviews > 0 ? `${pendingReviews} pendentes` : 'Em dia'}
                                </Text>
                            </View>
                        </View>
                        {pendingReviews > 0 && (
                            <View style={styles.badge}>
                                <Text style={styles.badgeText}>{pendingReviews}</Text>
                            </View>
                        )}
                    </View>
                </TouchableOpacity>

                {/* 2. RESUMO DE PROGRESSO */}
                <View style={[styles.card, { backgroundColor: theme.card }]}>
                    <Text style={[styles.sectionTitle, { color: theme.textSecondary }]}>RESUMO DE PROGRESSO</Text>

                    <View style={styles.statsRow}>
                        <View style={styles.statItem}>
                            <Text style={[styles.statValue, { color: theme.textPrimary }]}>{xp}</Text>
                            <Text style={[styles.statLabel, { color: theme.textSecondary }]}>XP TOTAL</Text>
                        </View>
                        <View style={styles.statSeparator} />
                        <View style={styles.statItem}>
                            <Text style={[styles.statValue, { color: theme.textPrimary }]}>{completed}</Text>
                            <Text style={[styles.statLabel, { color: theme.textSecondary }]}>AULAS</Text>
                        </View>
                    </View>

                    {/* Placeholder for "Missing X XP" since logic is not defined in scope */}
                    <Text style={[styles.progressText, { color: theme.textSecondary }]}>
                        Continue treinando para a próxima promoção.
                    </Text>
                </View>

                {/* 3. ACESSOS INSTITUCIONAIS */}
                <Text style={[styles.sectionHeader, { color: theme.textSecondary }]}>INSTITUCIONAL</Text>

                <TouchableOpacity
                    style={[styles.listItem, { backgroundColor: theme.card }]}
                    onPress={() => router.push('/(panel)/historico')}
                >
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                        <Ionicons name="time-outline" size={24} color={theme.primary} />
                        <Text style={[styles.listText, { color: theme.textPrimary }]}>Histórico de Progresso</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color={theme.textSecondary} />
                </TouchableOpacity>

                <TouchableOpacity
                    style={[styles.listItem, { backgroundColor: theme.card }]}
                    onPress={() => router.push('/(panel)/medalhas')}
                >
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                        <Ionicons name="ribbon-outline" size={24} color={theme.primary} />
                        <Text style={[styles.listText, { color: theme.textPrimary }]}>Medalhas & Condecorações</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color={theme.textSecondary} />
                </TouchableOpacity>

                <TouchableOpacity
                    style={[styles.listItem, { backgroundColor: theme.card }]}
                    onPress={() => router.push('/(panel)/manual')}
                >
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                        <Ionicons name="book-outline" size={24} color={theme.primary} />
                        <Text style={[styles.listText, { color: theme.textPrimary }]}>Manual & Regras</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color={theme.textSecondary} />
                </TouchableOpacity>

                <TouchableOpacity
                    style={[styles.listItem, { backgroundColor: theme.card }]}
                    onPress={() => router.push('/ranking')}
                >
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                        <Ionicons name="trophy-outline" size={24} color={theme.primary} />
                        <Text style={[styles.listText, { color: theme.textPrimary }]}>Ranking da Força</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color={theme.textSecondary} />
                </TouchableOpacity>

                <TouchableOpacity
                    style={[styles.listItem, { backgroundColor: theme.card }]}
                    onPress={() => router.push('/(panel)/champion')}
                >
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                        <Ionicons name="star-outline" size={24} color={theme.primary} />
                        <Text style={[styles.listText, { color: theme.textPrimary }]}>Campeão do Mês</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color={theme.textSecondary} />
                </TouchableOpacity>

            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
    },
    center: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    content: {
        gap: 20,
    },
    card: {
        padding: 20,
        borderRadius: 12,
        backgroundColor: '#1E1E1E', // Fallback
        elevation: 2,
    },
    cardRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    cardTitle: {
        fontSize: 16,
        fontWeight: 'bold',
        textTransform: 'uppercase',
    },
    cardSubtitle: {
        fontSize: 12,
    },
    badge: {
        backgroundColor: '#FF3B30',
        width: 24,
        height: 24,
        borderRadius: 12,
        justifyContent: 'center',
        alignItems: 'center',
    },
    badgeText: {
        color: '#FFF',
        fontSize: 12,
        fontWeight: 'bold',
    },
    sectionTitle: {
        fontSize: 12,
        fontWeight: 'bold',
        marginBottom: 16,
        letterSpacing: 1,
    },
    statsRow: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginBottom: 16,
    },
    statItem: {
        alignItems: 'center',
    },
    statValue: {
        fontSize: 24,
        fontWeight: 'bold',
    },
    statLabel: {
        fontSize: 10,
        marginTop: 4,
    },
    statSeparator: {
        width: 1,
        backgroundColor: 'rgba(255,255,255,0.1)',
    },
    progressText: {
        fontSize: 12,
        textAlign: 'center',
        opacity: 0.7,
    },
    sectionHeader: {
        fontSize: 12,
        fontWeight: 'bold',
        marginLeft: 4,
        marginBottom: -10,
        marginTop: 10,
    },
    listItem: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 16,
        borderRadius: 12,
    },
    listText: {
        fontSize: 16,
        fontWeight: '500',
    }
});