import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    FlatList,
    StyleSheet,
    SafeAreaView,
    TouchableOpacity,
    ActivityIndicator,
    Image
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { supabase } from '../../src/lib/supabase';
import { useForceTheme } from '../../src/context/ForceThemeContext';
import { useAuth } from '../../src/context/AuthContext';

type RankItem = {
    posicao: number;
    recruta_id: string;
    nome: string;
    xp: number;
    forca: 'marinha' | 'exercito' | 'aeronautica';
};

type MyPosition = {
    posicao: number;
    xp: number;
};

export default function RankingScreen() {
    const router = useRouter();
    const { session } = useAuth();
    const { theme, loading: themeLoading } = useForceTheme();

    const [ranking, setRanking] = useState<RankItem[]>([]);
    const [myPosition, setMyPosition] = useState<MyPosition | null>(null);
    const [loading, setLoading] = useState(true);

    // ⭐ LOADING STATE (CRITICAL GUARD)
    if (themeLoading || !theme) {
        return (
            <View style={{ flex: 1, backgroundColor: '#020B14', justifyContent: 'center', alignItems: 'center' }}>
                <ActivityIndicator size="large" color="#FFD166" />
            </View>
        );
    }

    // ⭐ DYNAMIC STYLES (After Guard)
    const styles = React.useMemo(() => getStyles(theme), [theme]);

    useEffect(() => {
        if (session?.user?.id) {
            loadData();
        }
    }, [session]);

    const loadData = async () => {
        try {
            setLoading(true);
            await Promise.all([loadRanking(), loadMyPosition()]);
        } catch (error) {
            console.error('Error loading ranking:', error);
        } finally {
            setLoading(false);
        }
    };

    const loadRanking = async () => {
        const { data, error } = await supabase
            .from('vw_ranking_mensal')
            .select('posicao, recruta_id, nome, xp, forca')
            .order('posicao')
            .limit(50); // Top 50

        if (error) throw error;
        if (data) setRanking(data);
    };

    const loadMyPosition = async () => {
        if (!session?.user?.id) return;

        const { data, error } = await supabase
            .from('vw_posicao_recruta_mes') // Views don't need update usually
            .select('posicao, xp')
            .eq('recruta_id', session.user.id)
            .maybeSingle();

        if (error) console.error('Error loading position:', error);
        if (data) setMyPosition(data);
    };

    const getForceLabel = (forca: string) => {
        switch (forca) {
            case 'marinha':
                return '⚓ Marinha';
            case 'exercito':
                return '🪖 Exército';
            case 'aeronautica':
                return '✈️ Aeronáutica';
            default:
                return '🎖️ Recruta';
        }
    };

    const renderTop3 = () => {
        if (ranking.length === 0) return null;

        const top3 = ranking.slice(0, 3);
        const podium = [
            top3[1] || null, // 2nd
            top3[0] || null, // 1st
            top3[2] || null  // 3rd
        ];

        return (
            <View style={styles.top3Container}>
                <Text style={styles.sectionTitle}>PELOTÃO DE ELITE</Text>
                <View style={styles.top3}>
                    {podium.map((item, index) => {
                        if (!item) return <View key={`empty-${index}`} style={styles.topCardPlaceholder} />;

                        const isFirst = index === 1;

                        return (
                            <View key={item.recruta_id} style={[styles.topCard, isFirst && styles.topCardFirst]}>
                                <Text style={[styles.topPos, isFirst && { color: theme.accent, fontSize: 24 }]}>#{item.posicao}</Text>
                                <View style={styles.avatarPlaceholder}>
                                    <Text style={{ fontSize: isFirst ? 24 : 16 }}>
                                        {item.forca === 'marinha' ? '⚓' : item.forca === 'aeronautica' ? '✈️' : '🪖'}
                                    </Text>
                                </View>
                                <Text style={styles.topName} numberOfLines={1}>{item.nome}</Text>
                                <Text style={styles.topXp}>{item.xp} XP</Text>
                            </View>
                        );
                    })}
                </View>
            </View>
        );
    };

    const renderItem = ({ item }: { item: RankItem }) => {
        if (item.posicao <= 3) return null;

        const isMe = item.recruta_id === session?.user?.id;

        return (
            <View style={[styles.item, isMe && styles.itemMe]}>
                <Text style={styles.pos}>{item.posicao}</Text>
                <View style={styles.info}>
                    <Text style={[styles.name, isMe && { color: theme.accent }]}>{item.nome}</Text>
                    <Text style={styles.forceSmall}>
                        {getForceLabel(item.forca)}
                    </Text>
                </View>
                <Text style={styles.xp}>{item.xp} XP</Text>
            </View>
        );
    };

    if (loading) {
        return (
            <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
                <ActivityIndicator color={theme.accent} />
            </View>
        )
    }

    return (
        <SafeAreaView style={styles.safe}>
            <View style={styles.header}>
                <TouchableOpacity onPress={() => router.back()} style={{ padding: 10 }}>
                    <Ionicons name="arrow-back" size={24} color={theme.accent} />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>RANKING GERAL</Text>
                <View style={{ width: 44 }} />
            </View>

            <FlatList
                data={ranking}
                keyExtractor={(item) => item.recruta_id}
                ListHeaderComponent={renderTop3}
                renderItem={renderItem}
                contentContainerStyle={{ paddingBottom: 100 }}
            />

            {myPosition && (
                <View style={styles.myPosition}>
                    <Text style={styles.myText}>
                        SUA POSIÇÃO ESTE MÊS
                    </Text>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 5 }}>
                        <Text style={styles.myRank}>#{myPosition.posicao}</Text>
                        <Text style={[styles.myRank, { color: theme.primary }]}>{myPosition.xp} XP</Text>
                    </View>
                </View>
            )}
        </SafeAreaView>
    );
}

// Helper to create styles based on theme
const getStyles = (theme: any) => StyleSheet.create({
    safe: {
        flex: 1,
        backgroundColor: theme?.background ?? '#020B14',
    },
    container: {
        flex: 1,
        backgroundColor: theme?.background ?? '#020B14',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 10,
        paddingVertical: 15,
        borderBottomWidth: 1,
        borderBottomColor: 'rgba(255,255,255,0.1)',
        backgroundColor: theme?.card ?? '#0F1E2E',
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: theme?.accent ?? '#FFD166',
        textTransform: 'uppercase',
    },
    sectionTitle: {
        color: theme?.textSecondary ?? '#AAB8C2',
        fontSize: 12,
        fontWeight: 'bold',
        textAlign: 'center',
        marginBottom: 15,
        letterSpacing: 1,
    },

    /* TOP 3 */
    top3Container: {
        marginBottom: 20,
        marginTop: 20,
    },
    top3: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingHorizontal: 16,
        gap: 10,
    },
    topCard: {
        backgroundColor: theme?.card ?? '#0F1E2E',
        padding: 10,
        borderRadius: 12,
        alignItems: 'center',
        width: '30%',
        borderWidth: 1,
        borderColor: 'rgba(255,255,255,0.1)',
    },
    topCardFirst: {
        backgroundColor: theme?.primary ?? '#0A2540',
        borderColor: theme?.accent ?? '#FFD166',
        paddingBottom: 20,
        transform: [{ scale: 1.1 }],
        zIndex: 10,
    },
    topCardPlaceholder: {
        width: '30%',
    },
    topPos: {
        fontSize: 14,
        fontWeight: '700',
        color: theme?.textSecondary ?? '#AAB8C2',
        marginBottom: 5,
    },
    avatarPlaceholder: {
        marginBottom: 5,
    },
    topName: {
        color: theme?.textPrimary ?? '#FFFFFF',
        fontWeight: '600',
        fontSize: 12,
        textAlign: 'center',
        marginBottom: 2,
    },
    topXp: {
        color: theme?.textSecondary ?? '#AAB8C2',
        fontSize: 10,
        fontWeight: 'bold',
    },

    /* LISTA */
    item: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 16,
        borderBottomWidth: 1,
        borderBottomColor: 'rgba(255,255,255,0.05)',
    },
    itemMe: {
        backgroundColor: 'rgba(255, 255, 255, 0.05)',
    },
    pos: {
        width: 40,
        color: theme?.textSecondary ?? '#AAB8C2',
        fontWeight: 'bold',
        fontSize: 16,
    },
    info: {
        flex: 1,
    },
    name: {
        color: theme?.textPrimary ?? '#FFFFFF',
        fontWeight: '500',
        fontSize: 16,
    },
    xp: {
        color: theme?.accent ?? '#FFD166', // Was 'progress' which was undefined context? using accent
        fontWeight: '600',
    },

    /* FORÇA */
    force: {
        marginTop: 4,
        fontSize: 11,
        color: '#aaa',
    },
    forceSmall: {
        fontSize: 11,
        color: theme?.textSecondary ?? '#AAB8C2',
        marginTop: 2,
    },

    /* MINHA POSIÇÃO */
    myPosition: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        padding: 20,
        borderTopWidth: 1,
        borderTopColor: theme?.accent ?? '#FFD166',
        backgroundColor: theme?.card ?? '#0F1E2E',
        elevation: 20,
    },
    myText: {
        color: theme?.textSecondary ?? '#AAB8C2',
        fontSize: 10,
        fontWeight: 'bold',
        textTransform: 'uppercase',
    },
    myRank: {
        color: theme?.textPrimary ?? '#FFFFFF',
        fontSize: 18,
        fontWeight: 'bold',
    },
});
