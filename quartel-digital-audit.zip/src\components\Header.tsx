import React from 'react';
import { View, Text, StyleSheet } from "react-native";
import { theme } from "../theme";

export function Header({ title, subtitle, rightAction }: { title: string, subtitle?: string, rightAction?: React.ReactNode }) {
    return (
        <View style={styles.container}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                <View>
                    <Text style={styles.title}>{title}</Text>
                    {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
                </View>
                {rightAction}
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { marginBottom: 16 },
    title: {
        color: theme.colors.textPrimary,
        fontSize: 22,
        fontWeight: "700",
    },
    subtitle: {
        color: theme.colors.textSecondary,
        fontSize: 14,
        marginTop: 4,
    },
});
