import React, { useState, useMemo } from 'react';
import { View, Text, StyleSheet, SectionList, TouchableOpacity, ActivityIndicator, ScrollView } from 'react-native';
import { useForceTheme } from '../../src/context/ForceThemeContext';
import { useAuth } from '../../src/context/AuthContext';
import { useHistory, HistoryEvent } from '../../src/hooks/useHistory';
import { Header } from '../../src/components/Header';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

type FilterType = 'todos' | 'aula' | 'revisao' | 'quiz' | 'xp' | 'medalha';

const FILTERS: { id: FilterType; label: string }[] = [
    { id: 'todos', label: 'Todos' },
    { id: 'aula', label: 'Aulas' },
    { id: 'revisao', label: 'Revisões' },
    { id: 'quiz', label: 'Quiz' },
    { id: 'xp', label: 'XP' },
    { id: 'medalha', label: 'Medalhas' },
];

export default function HistoricoScreen() {
    const { theme } = useForceTheme();
    const { session } = useAuth();
    const router = useRouter();
    const { history, loading } = useHistory(session?.user?.id || '');
    const [activeFilter, setActiveFilter] = useState<FilterType>('todos');

    // B1: FILTERS & B2: DATE GROUPING
    const sections = useMemo(() => {
        let filtered = history;

        // Apply Filter
        if (activeFilter !== 'todos') {
            filtered = history.filter(item => {
                // Determine type based on referencia or logic
                const ref = item.referencia?.toLowerCase() || '';
                // Simple mapping; adjust if DB values differ
                if (activeFilter === 'aula') return ref.includes('aula');
                if (activeFilter === 'revisao') return ref.includes('revisao') || ref.includes('revisão');
                if (activeFilter === 'quiz') return ref.includes('quiz');
                if (activeFilter === 'medalha') return ref.includes('medalha') || ref.includes('condecor');
                if (activeFilter === 'xp') return item.impacto && !ref; // XP generic if no other ref
                return false;
            });
        }

        // Group by Date
        const grouped: Record<string, HistoryEvent[]> = {};

        filtered.forEach(item => {
            const dateObj = new Date(item.created_at);
            // Format: "12 de março de 2026"
            const dateKey = format(dateObj, "d 'de' MMMM 'de' yyyy", { locale: ptBR });

            if (!grouped[dateKey]) {
                grouped[dateKey] = [];
            }
            grouped[dateKey].push(item);
        });

        // Convert to SectionList sections
        return Object.keys(grouped).map(date => ({
            title: date,
            data: grouped[date]
        }));
    }, [history, activeFilter]);

    // B3: ICONS
    const getIconName = (referencia: string | null): keyof typeof Ionicons.glyphMap => {
        const ref = referencia?.toLowerCase() || '';
        if (ref.includes('aula')) return 'book-outline';
        if (ref.includes('revisao') || ref.includes('revisão')) return 'refresh-circle-outline';
        if (ref.includes('quiz')) return 'checkbox-outline';
        if (ref.includes('medalha') || ref.includes('condecor')) return 'ribbon-outline';
        return 'time-outline'; // Default generic
    };

    // B4: NAVIGATION
    const handleNavigate = (item: HistoryEvent) => {
        if (!item.source_id) return;

        const ref = item.referencia?.toLowerCase() || '';
        if (ref.includes('aula')) {
            router.push({ pathname: '/(lessons)/[lessonId]', params: { lessonId: item.source_id } });
        } else if (ref.includes('revisao')) {
            // Check if source_id is lesson_id or review_id. Assuming lesson_id context.
            router.push({ pathname: '/(lessons)/[lessonId]/review', params: { lessonId: item.source_id } });
        }
        // Add other mappings as strictly needed
    };

    const renderItem = ({ item }: { item: HistoryEvent }) => {
        const icon = getIconName(item.referencia);
        const hasLink = !!item.source_id && (item.referencia?.includes('aula') || item.referencia?.includes('revisao'));

        return (
            <View style={[styles.row, { borderBottomColor: 'rgba(255,255,255,0.05)' }]}>
                {/* Icon Column (B3) */}
                <View style={styles.iconCol}>
                    <Ionicons name={icon} size={20} color={theme.textSecondary} />
                </View>

                {/* Content Column */}
                <View style={styles.contentCol}>
                    <Text style={[styles.description, { color: theme.textPrimary }]}>
                        {item.description}
                    </Text>

                    <View style={styles.metaRow}>
                        {item.impacto && (
                            <Text style={[styles.impact, { color: '#4ADE80' }]}>
                                +{item.impacto} XP
                            </Text>
                        )}

                        {/* B4: Link Button */}
                        {hasLink && (
                            <TouchableOpacity
                                onPress={() => handleNavigate(item)}
                                style={[styles.linkButton, { borderColor: theme.primary }]}
                            >
                                <Text style={[styles.linkText, { color: theme.primary }]}>
                                    {item.referencia?.includes('revisao') ? 'VER REVISÃO' : 'VER AULA'}
                                </Text>
                                <Ionicons name="arrow-forward" size={10} color={theme.primary} />
                            </TouchableOpacity>
                        )}
                    </View>
                </View>
            </View>
        );
    };

    const renderHeader = ({ section: { title } }: { section: { title: string } }) => (
        <View style={[styles.sectionHeader, { backgroundColor: theme.background }]}>
            <Text style={[styles.sectionTitle, { color: theme.textSecondary }]}>{title}</Text>
        </View>
    );

    if (loading) {
        return (
            <View style={[styles.center, { backgroundColor: theme.background }]}>
                <ActivityIndicator size="large" color={theme.primary || '#FFD166'} />
            </View>
        );
    }

    return (
        <View style={[styles.container, { backgroundColor: theme.background }]}>
            <View style={{ paddingHorizontal: 20 }}>
                <Header title="HISTÓRICO DE PROGRESSO" />
            </View>

            {/* B1: FILTERS */}
            <View style={styles.filtersContainer}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filtersContent}>
                    {FILTERS.map(filter => (
                        <TouchableOpacity
                            key={filter.id}
                            style={[
                                styles.filterChip,
                                {
                                    backgroundColor: activeFilter === filter.id ? theme.primary : 'rgba(255,255,255,0.1)',
                                    borderColor: activeFilter === filter.id ? theme.primary : 'transparent'
                                }
                            ]}
                            onPress={() => setActiveFilter(filter.id)}
                        >
                            <Text style={{
                                color: activeFilter === filter.id ? '#000' : theme.textSecondary,
                                fontWeight: 'bold',
                                fontSize: 12
                            }}>
                                {filter.label}
                            </Text>
                        </TouchableOpacity>
                    ))}
                </ScrollView>
            </View>

            <SectionList
                sections={sections}
                renderItem={renderItem}
                renderSectionHeader={renderHeader}
                keyExtractor={(item, index) => item.id || `hist-${index}`}
                contentContainerStyle={styles.listContent}
                stickySectionHeadersEnabled={false}
                ListEmptyComponent={
                    <Text style={[styles.emptyText, { color: theme.textSecondary }]}>
                        Nenhum evento encontrado para este filtro.
                    </Text>
                }
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    center: {
        flex: 1, // ensure full height for centering
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: 200, // safe min height
    },
    listContent: {
        paddingBottom: 40,
    },
    filtersContainer: {
        height: 50,
        marginBottom: 10,
    },
    filtersContent: {
        paddingHorizontal: 20,
        gap: 8,
        alignItems: 'center',
    },
    filterChip: {
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 20,
        borderWidth: 1,
    },
    sectionHeader: {
        paddingVertical: 12,
        paddingHorizontal: 20,
        marginTop: 10,
    },
    sectionTitle: {
        fontSize: 12,
        fontWeight: 'bold',
        textTransform: 'uppercase',
        letterSpacing: 1,
        opacity: 0.7,
    },
    row: {
        flexDirection: 'row',
        paddingVertical: 16,
        paddingHorizontal: 20,
        borderBottomWidth: 1,
        alignItems: 'flex-start', // Align tops if multiline
    },
    iconCol: {
        width: 40,
        paddingTop: 2,
    },
    contentCol: {
        flex: 1,
    },
    description: {
        fontSize: 14,
        fontWeight: '500',
        marginBottom: 8,
        lineHeight: 20,
    },
    metaRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        flexWrap: 'wrap',
    },
    impact: {
        fontSize: 12,
        fontWeight: 'bold',
    },
    linkButton: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        borderWidth: 1,
        borderRadius: 4,
        paddingHorizontal: 8,
        paddingVertical: 4,
    },
    linkText: {
        fontSize: 10,
        fontWeight: 'bold',
        textTransform: 'uppercase',
    },
    emptyText: {
        textAlign: 'center',
        marginTop: 40,
        opacity: 0.6,
    }
});
