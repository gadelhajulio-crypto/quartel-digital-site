import React from 'react';
import { View, Text, StyleSheet } from "react-native";
import { theme } from "../../src/theme";
import { Header } from "../../src/components/Header";
import { ProgressCard } from "../../src/components/ProgressCard";

export default function Progresso() {
    return (
        <View style={styles.container}>
            <Header title="SEU PROGRESSO" />
            <ProgressCard />
            <View style={{ marginTop: 20 }}>
                <Text style={{ color: theme.colors.textSecondary, textAlign: 'center' }}>Estatísticas Detalhadas em Breve.</Text>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: theme.colors.background,
        flex: 1,
        padding: 16,
    },
});
