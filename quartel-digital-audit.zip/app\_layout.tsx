import React, { useEffect, useState, useRef } from 'react';
import { Slot, useRouter, useSegments } from 'expo-router';
import { AuthProvider, useAuth } from '../src/context/AuthContext';
import { ForceThemeProvider } from '../src/context/ForceThemeContext';
import { View, ActivityIndicator } from 'react-native';
import { Asset } from 'expo-asset';
import { colors } from '../src/theme';
import { INSTRUCTOR_AVATARS } from '../src/constants/instructorAvatars';

/**
 * ROOT NAVIGATION GUARD
 * - Preload completo de assets
 * - Controle de autenticação
 * - Fonte única de decisão de navegação
 */
function RootLayoutNav() {
  const { session, loading } = useAuth();
  const segments = useSegments();
  const router = useRouter();

  const [assetsReady, setAssetsReady] = useState(false);
  const initialSegment = useRef<string | undefined>(segments[0]);

  /**
   * PRELOAD GLOBAL DE IMAGENS
   * (executa UMA ÚNICA VEZ)
   */
  useEffect(() => {
    let isMounted = true;

    async function preloadAssets() {
      try {
        const images = [
          // Avatares
          INSTRUCTOR_AVATARS.objetivo,
          INSTRUCTOR_AVATARS.estrategico,
          INSTRUCTOR_AVATARS.didatico,

          // Seleção - Marinha
          require('../assets/instructors/marinha/objetivo/instrutor-objetivo-marinha-selecao.png'),
          require('../assets/instructors/marinha/estrategico/instrutor-estrategico-marinha-selecao.png'),
          require('../assets/instructors/marinha/didatica/instrutor-didatica-marinha-selecao.png'),

          // Confirmação - Marinha
          require('../assets/instructors/marinha/objetivo/instrutor-objetivo-marinha-confirmacao.png'),
          require('../assets/instructors/marinha/estrategico/instrutor-estrategico-marinha-confirmacao.png'),
          require('../assets/instructors/marinha/didatica/instrutor-didatica-marinha-confirmacao.png'),
        ];

        await Promise.all(
          images.map(img => Asset.fromModule(img).downloadAsync())
        );
      } catch (error) {
        console.warn('[ROOT] Asset preload warning:', error);
      } finally {
        if (isMounted) setAssetsReady(true);
      }
    }

    preloadAssets();

    return () => {
      isMounted = false;
    };
  }, []);

  /**
   * GUARDA DE NAVEGAÇÃO
   */
  useEffect(() => {
    if (!assetsReady || loading) return;

    const currentGroup = segments[0];

    // Usuário logado em auth → app
    if (session && currentGroup === '(auth)') {
      router.replace('/(app)');
      return;
    }

    // Usuário deslogado tentando acessar app → login
    if (!session && currentGroup === '(app)') {
      router.replace('/(auth)/login');
      return;
    }

    // Se estiver na raiz, redirecionar baseado na sessão
    if (segments.length === 0) {
      if (session) {
        router.replace('/(app)');
      } else {
        router.replace('/(auth)/login');
      }
    }

  }, [session, loading, assetsReady, segments]);

  /**
   * SPLASH CONTROLADO
   */
  if (loading || !assetsReady) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: colors.background,
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <ActivityIndicator size="large" color={colors.gold} />
      </View>
    );
  }

  return <Slot />;
}

/**
 * ROOT PROVIDERS
 */
export default function RootLayout() {
  return (
    <AuthProvider>
      <ForceThemeProvider>
        <RootLayoutNav />
      </ForceThemeProvider>
    </AuthProvider>
  );
}
