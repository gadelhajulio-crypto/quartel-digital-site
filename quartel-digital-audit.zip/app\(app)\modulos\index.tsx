import React from 'react';
import ModulesScreen from '../../../src/screens/ModulesScreen';

export default function ModulesRoute() {
    return <ModulesScreen />;
}
