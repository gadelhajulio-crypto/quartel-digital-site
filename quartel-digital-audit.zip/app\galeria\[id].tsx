import { View, Text, Image, ActivityIndicator } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { useEffect, useState } from "react";
import { fetchGaleria } from "../../src/services/galeria";

export default function GaleriaDetalhe() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [item, setItem] = useState<any | null>(null);

  useEffect(() => {
    fetchGaleria().then((data) => {
      const found = data.find((i: any) => i.id === id);
      setItem(found ?? null);
    });
  }, [id]);

  if (!item) {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, padding: 24, alignItems: "center" }}>
      <Image
        source={item.foto_url ? { uri: item.foto_url } : undefined}
        style={{
          width: 200,
          height: 200,
          borderRadius: 100,
          marginBottom: 24,
          backgroundColor: "#ccc",
        }}
      />

      <Text style={{ fontSize: 22, fontWeight: "bold" }}>
        🎖 Recruta Padrão
      </Text>

      <Text style={{ marginTop: 8, color: "#666" }}>
        Conquista em {new Date(item.created_at).toLocaleDateString()}
      </Text>
    </View>
  );
}
