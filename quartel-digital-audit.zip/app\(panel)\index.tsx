import React from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import { useRecruitPanel } from '../../src/hooks/useRecruitPanel';
import { IndicatorCard } from '../../src/components/panel/IndicatorCard';
import { StatusBadge } from '../../src/components/panel/StatusBadge';
import { useAuth } from '../../src/context/AuthContext';
import { theme } from '../../src/theme';
import { Header } from '../../src/components/Header';

export default function PanelScreen() {
    const { session } = useAuth();
    const userId = session?.user?.id;
    // Previously 'marinha' was hardcoded or derived. We'll use 'marinha' as default or derive from profile if available.
    // For now, hardcoded as per prompt guidance (since userForce='marinha' in prompt).
    const userForce = 'marinha';

    const { xp, ranking, completed, isChampion, loading } = useRecruitPanel(userId!, userForce);

    if (loading) {
        return (
            <View style={[styles.container, styles.center]}>
                <ActivityIndicator size="large" color={theme.colors.gold || '#FFD166'} />
            </View>
        );
    }

    return (
        <ScrollView style={styles.container}>
            <Header title="PAINEL DO RECRUTA" />

            <View style={styles.content}>
                <View style={styles.row}>
                    <IndicatorCard label="XP do Mês" value={xp} />
                    <IndicatorCard label="Ranking Assuntos" value={`${ranking}º`} />
                    <IndicatorCard label="Aulas Concluídas" value={completed} />
                </View>

                <StatusBadge isChampion={isChampion} />

                <Text style={styles.disclaimer}>
                    Ranking atualizado automaticamente
                </Text>
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
    },
    center: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    content: {
        padding: 16,
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        gap: 8,
        marginBottom: 16,
    },
    disclaimer: {
        opacity: 0.6,
        marginTop: 16,
        color: theme.colors.textSecondary,
        fontSize: 12,
        textAlign: 'center',
    }
});
